import React from 'react';
import '../css/login.css'
import { Link } from 'react-router-dom'

function login() {

  return (
    <>
      <div className='dash'>
        <h1 className='welcome'>Welcome</h1>
        <div className='select'>
          <h4 className='h4'><Link className='login_links' to='/dashboard'>Dashboard</Link></h4>
          <h4 className='h4'><Link className='login_links' to='/register'>Register</Link></h4>
        </div>

      </div>
      <div className="background">
        <div className="shape"></div>
        <div className="shape"></div>
      </div>
      <form>
        <h3>Login Here</h3>

        <label for="sid">Student ID</label>
        <input type="text" placeholder="Student ID" id="sid" required />

        <label for="pin">Pin</label>
        <input type="password" placeholder="Pin" id="pin" required />

        <button>Log In</button>
        <p>Don't have an account?Register</p>
      </form>
      
    </>
  )
}

export default login