import React from 'react';
import '../css/login.css'
import { Link } from 'react-router-dom'

function register() {

  return (
    <>
      <div className='dash'>
        <h1 className='welcome'>Welcome</h1>
        <div className='select'>
          <h4 className='h4'><Link className='login_links' to='/dashboard'>Dashboard</Link></h4>
          <h4 className='h4'><Link className='login_links' to='/login'>Log In</Link></h4>
        </div>

      </div>
      <div className="background">
        <div className="shape"></div>
        <div className="shape"></div>
      </div>
      <form style={{ height: '650px' }}>
        <h3>Register Here</h3>

        <label for="sid">Student ID</label>
        <input type="text" placeholder="Student ID" id="sid" required/>

        <label for="pin">Pin</label>
        <input type="password" placeholder="Pin" id="pin" required/>

        <label for="password">Confirm Password</label>
        <input type="password" placeholder="Confirm Pin" id="password" />

        <button>Register</button>
        <p>Already have an account?Login</p>

      </form>
      
    </>
  )
}

export default register