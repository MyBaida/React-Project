import React from 'react';
import '../css/login.css'
import { Link } from 'react-router-dom'

function StudentInfo() {

    return (
        <>
            <div className="background">
                <div className="shape"></div>
                <div className="shape"></div>
            </div>
            <form className='form2'>
                <h3>Enter Your Information Below</h3>

                <label for="name">Full Name</label>
                <input type="text" placeholder="First Name First" id="name" required/>

                <label for="sid">Student ID</label>
                <input type="text" placeholder="Student ID" id="sid" required/>

                <label for="contact">Email</label>
                <input type="tel" placeholder="0200xxxxxx" id="contact" />

                <label for="course">Programme of Study</label>
                <input type="text" placeholder="Computer Engineering" id="course" />

                <label for="level">Level</label>
                <input type="text" placeholder="Level 200" id="level" />

                <label for="pin">Pin</label>
                <input type="password" placeholder="Pin" id="pin" required/>


                <button>Submit info</button>
                <Link className='login_links' to='/dashboard'><button className='dashboard-btn'>Back to Dashboard</button></Link>

            </form>
        </>
    );
}

export default StudentInfo