import React from 'react';
import { Link } from 'react-router-dom'
import '../css/dashboard.css'



function dashboard() {


    return (
        <>
            <div className="app">
                <header className="app-header">
                    <div className="app-header-logo">
                        <div className="logo">
                            <span className="logo-icon">
                                <img alt='' src="https://assets.codepen.io/285131/almeria-logo.svg" />
                            </span>
                            <h1 className="logo-title">
                                <span>University of</span>
                                <span>Ghana</span>
                            </h1>
                        </div>
                    </div>
                    <div className="app-header-navigation">
                        <div className="tabs">
                            <Link to="/dashboard">
                                Courses
                            </Link>
                            <Link className="/dashboard">
                                Inbox
                            </Link>
                            <Link to="/dashboard">
                                Personal Info
                            </Link>
                        </div>
                    </div>
                    <div>
                        <button className="user-profile">
                            <span>Abdul Fatahu Adam</span>

                            <span>
                                <img alt='' src="https://cdn2.iconfinder.com/data/icons/avatars-99/62/avatar-370-456322-512.png" />
                            </span>
                        </button>
                    </div>

                </header>
                <div className="app-body">
                        <nav className="navigation">
                            <p>
                                Differential Equation
                            </p>
                            <p>
                                Data Structures and Algorithms
                            </p>
                            <p>
                                Digital Systems Design
                            </p>
                            <p>
                                Software Engineering
                            </p>
                            <p>
                                Linear Circuit
                            </p>
                            <p>
                                Data Communications
                            </p>
                            <p>
                                CBAS:Academic Writing II
                            </p>
                            <Link to="/register"><p className='extra'>Register</p></Link>
                            <Link to="/login"><p className='extra'>Logout</p></Link>
                            <Link to="/student_info"><p className='extra'>Student Info Entry</p></Link>
                        </nav>

                    <div>
                        <section>
                            <h2>Computer Engineering</h2>

                                <div className="dropdown-field">
                                    <select>
                                        <option>L100</option>
                                        <option selected>L200</option>
                                        <option>L300</option>
                                        <option>L400</option>
                                    </select>
                                </div>

                            <div className="tiles">
                                <article className="tile">
                                    <div className="tile-header">
                                        <h3>
                                            Announcements

                                        </h3>
                                    </div>
                                    <Link to="/dashboard">
                                        <span>Download</span>
                                    </Link>
                                </article>
                                <article className="tile">
                                    <div className="tile-header">
                                        <h3>
                                            Course Materials
                                        </h3>
                                    </div>
                                    <Link to="/dashboard">
                                        <span>Download</span>
                                    </Link>
                                </article>
                                <article className="tile">
                                    <div className="tile-header">
                                        <h3>
                                            Event Calendar
                                        </h3>
                                    </div>
                                    <Link to="/dashboard">
                                        <span>Download</span>
                                    </Link>
                                </article>
                            </div>

                        </section>
                        <section >
                            <div className="transfer-section-header">
                                <h2><Link to="/dashboard"> Extracurricular Activities</Link></h2>
                            </div>

                        </section>
                    </div>
                    <div className="app-body-sidebar">
                        <section>
                            <h2><Link to="/dashboard">Course Overview</Link></h2>

                            <div>
                                <p>Tasks</p>

                            </div>
                            <div className="pams">
                                <div className="pam">
                                    <div className="task green">
                                        <span>Tasks</span>
                                        <span>
                                            Due
                                        </span>
                                    </div>
                                </div>
                                <div className="pam">
                                    <div className="task olive">
                                        <span>Tasks</span>
                                        <span>
                                            Completed
                                        </span>
                                    </div>
                                </div>
                                <div className="pam">
                                    <div className="task gray">
                                        <span>Grade</span>
                                        <span>
                                            Book
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div className="faq">
                                <p>Send Message to the Class</p>
                                <div>
                                    <label>Message</label>
                                    <input type="text" placeholder="Type here" />
                                </div>
                            </div>
                            <div className="end-section-footer">
                                <button className="save-button">
                                    Send
                                </button>
                                <button className="settings-button">
                                    <span>Account and Settings</span>
                                </button>
                            </div>
                        </section>
                    </div>
                </div>
            </div>

        </>
    )
}

export default dashboard